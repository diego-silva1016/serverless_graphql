"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.graphqlHandler = void 0;
const server_1 = require("@apollo/server");
const drainHttpServer_1 = require("@apollo/server/plugin/drainHttpServer");
const schema_1 = require("@graphql-tools/schema");
const ws_1 = require("ws");
const ws_2 = require("graphql-ws/lib/use/ws");
const database_1 = require("firebase/database");
const express4_1 = require("@apollo/server/express4");
const serverless_express_1 = __importDefault(require("@vendia/serverless-express"));
const cors_1 = __importDefault(require("cors"));
const http_1 = __importDefault(require("http"));
const body_parser_1 = __importDefault(require("body-parser"));
const express_1 = __importDefault(require("express"));
const graphql_subscriptions_1 = require("graphql-subscriptions");
const app_1 = require("firebase/app");
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries
// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: process.env.NODE_FIREBASE_SECRET,
    authDomain: "letmeask-97faa.firebaseapp.com",
    databaseURL: "https://letmeask-97faa-default-rtdb.firebaseio.com",
    projectId: "letmeask-97faa",
    storageBucket: "letmeask-97faa.appspot.com",
    messagingSenderId: "592076087336",
    appId: "1:592076087336:web:30f490a3e0b48f4a14d51d"
};
// Initialize Firebase
(0, app_1.initializeApp)(firebaseConfig);
const app = (0, express_1.default)();
const httpServer = http_1.default.createServer(app);
const pubsub = new graphql_subscriptions_1.PubSub();
const typeDefs = `
  type Vote {
    option: String
    votes: Int
  }
  
  type Enquete {
    title: String
    votes: [Vote]
  }

  type Query {
    enquetes: [Enquete]
    enquete(title: String): Enquete
  }

  type Mutation {
    addEnquete(title: String, options: [String]): Enquete,
    voteEnquete(title: String, option: String): Enquete
  }

  type Subscription {
    enqueteCreated: Enquete,
    enqueteUpdated: Enquete
  }
`;
const resolvers = {
    Query: {
        enquetes: async () => {
            const db = (0, database_1.getDatabase)();
            return await (0, database_1.get)((0, database_1.child)((0, database_1.ref)(db), `enquetes`)).then((snapshot) => {
                const obj = snapshot.val();
                return Object.keys(obj).map(key => ({
                    title: key,
                    ...obj[key]
                }));
            });
        },
        enquete: async (_, { title }) => {
            const db = (0, database_1.getDatabase)();
            return await (0, database_1.get)((0, database_1.child)((0, database_1.ref)(db), `enquetes/${title}`)).then((snapshot) => {
                const obj = snapshot.val();
                return {
                    title,
                    ...obj
                };
            });
        }
    },
    Mutation: {
        addEnquete(_, { title, options }) {
            const votes = options.map(option => ({
                option,
                votes: 0
            }));
            const db = (0, database_1.getDatabase)();
            (0, database_1.set)((0, database_1.ref)(db, `enquetes/${title}`), {
                votes: votes
            });
            const enquete = {
                title,
                votes
            };
            pubsub.publish('ENQUETE_CREATED', { enqueteCreated: enquete });
            return enquete;
        },
        voteEnquete: async (_, { title, option }) => {
            const db = (0, database_1.getDatabase)();
            await (0, database_1.get)((0, database_1.child)((0, database_1.ref)(db), `enquetes/${title}`)).then((snapshot) => {
                if (snapshot.exists()) {
                    const newVotes = snapshot.val().votes.map(vote => ({
                        option: vote.option,
                        votes: vote.option === option ? ++vote.votes : vote.votes
                    }));
                    (0, database_1.update)((0, database_1.ref)(db, `enquetes/${title}`), {
                        votes: newVotes
                    });
                    pubsub.publish('ENQUETE_UPDATED', { enqueteUpdated: { title, votes: newVotes } });
                    return snapshot.val();
                }
                else {
                    console.log("No data available");
                }
            });
        },
    },
    Subscription: {
        enqueteCreated: {
            subscribe: () => pubsub.asyncIterator(['ENQUETE_CREATED'])
        },
        enqueteUpdated: {
            subscribe: () => pubsub.asyncIterator(['ENQUETE_UPDATED'])
        }
    }
};
const schema = (0, schema_1.makeExecutableSchema)({ typeDefs, resolvers });
const wsServer = new ws_1.WebSocketServer({
    server: httpServer,
    path: '/',
});
const serverCleanup = (0, ws_2.useServer)({ schema }, wsServer);
const server = new server_1.ApolloServer({
    schema,
    plugins: [
        (0, drainHttpServer_1.ApolloServerPluginDrainHttpServer)({ httpServer }),
        {
            async serverWillStart() {
                return {
                    async drainServer() {
                        await serverCleanup.dispose();
                    },
                };
            },
        },
    ],
});
// export const graphqlHandler = startServerAndCreateLambdaHandler(
//   server,
//   // We will be using the Proxy V2 handler
//   handlers.createAPIGatewayProxyEventV2RequestHandler(),
// );
await server.start();
app.use('/', (0, cors_1.default)(), body_parser_1.default.json(), (0, express4_1.expressMiddleware)(server));
exports.graphqlHandler = (0, serverless_express_1.default)({ app });
// const PORT = 4000;
// // Modified server startup
// await new Promise<void>((resolve) => httpServer.listen({ port: PORT }, resolve));
