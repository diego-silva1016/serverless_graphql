
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'diegoribeiro',
  applicationName: 'apollo-lambda',
  appUid: '2c7cP3mjNX7nyLJyt5',
  orgUid: '2673a8be-85c1-43ea-ba1f-ac0ca8599be8',
  deploymentUid: '1fcf359c-088c-4bf1-96f8-fe9aa0f51460',
  serviceName: 'apollo-lambda',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'apollo-lambda-dev-ws', timeout: 6 };

try {
  const userHandler = require('./src/index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.graphqlHandler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}